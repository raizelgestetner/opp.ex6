package oop.ex6.type_checker;

public class InvalidMethodNameException extends Exception {
}
