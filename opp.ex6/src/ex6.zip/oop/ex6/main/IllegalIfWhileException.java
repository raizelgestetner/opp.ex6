package oop.ex6.main;

public class IllegalIfWhileException extends Exception {
}
