package oop.ex6.main;

public class UndeclaredMethodException extends Exception {
}
