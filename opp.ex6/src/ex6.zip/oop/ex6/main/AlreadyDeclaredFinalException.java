package oop.ex6.main;

public class AlreadyDeclaredFinalException extends Exception {
}
