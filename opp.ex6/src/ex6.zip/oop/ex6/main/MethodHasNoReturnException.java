package oop.ex6.main;

public class MethodHasNoReturnException extends Exception {
}
