package oop.ex6.main;

public class InvalidReturnException extends Error {
}
