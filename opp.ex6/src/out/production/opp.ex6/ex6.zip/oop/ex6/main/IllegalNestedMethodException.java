package oop.ex6.main;

public class IllegalNestedMethodException extends Exception {
}
