package oop.ex6.main;

public class StartOfLineException extends Exception {
}
