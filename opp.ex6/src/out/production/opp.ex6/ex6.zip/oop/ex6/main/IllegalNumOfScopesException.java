package oop.ex6.main;

public class IllegalNumOfScopesException extends Exception {
}
