package oop.ex6.main;

public class IllegalMethodCallException extends Exception {
}
