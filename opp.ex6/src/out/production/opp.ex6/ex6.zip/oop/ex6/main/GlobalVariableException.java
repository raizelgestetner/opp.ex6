package oop.ex6.main;

public class GlobalVariableException extends Exception {
}
